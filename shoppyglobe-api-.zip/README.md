# ShoppyGlobe API

Backend API for ShoppyGlobe E-commerce application built with Node.js, Express, and MongoDB.

## Features
- User authentication with JWT
- Product management (fetch all, fetch by ID)
- Cart management (add, update, delete)
- Protected routes with middleware

## Installation
```bash
git clone https://github.com/Gaurav1148f/Build-APIs-with-Node.js-and-Express.js-for-Shoppyglobe-E-commerce
cd shoppyglobe-api
npm install
npm start
```

## API Endpoints
- `GET /products` - Get all products
- `GET /products/:id` - Get single product by ID
- `POST /register` - Register user
- `POST /login` - Login user and get token
- `POST /cart` - Add product to cart (protected)
- `PUT /cart/:productId` - Update product quantity (protected)
- `DELETE /cart/:productId` - Remove product from cart (protected)

## Owner
- **Name:** Gaurav1148
- **GitHub:** [Repository Link](https://github.com/Gaurav1148f/Build-APIs-with-Node.js-and-Express.js-for-Shoppyglobe-E-commerce)

## License
This project is licensed under the MIT License.
